# Plan for Kiros Asefa's AI Portfolio Website

Build a futuristic, responsive, and visually impressive portfolio using React 19, Tailwind CSS, and Framer Motion.

## 1. Project Structure
- `src/components/layout/Navbar.tsx`: Sticky navigation with glassmorphism.
- `src/components/layout/Footer.tsx`: Professional footer with social links.
- `src/components/sections/Hero.tsx`: Animated typing intro and AI-themed background.
- `src/components/sections/About.tsx`: Bio and education details.
- `src/components/sections/Skills.tsx`: Animated cards with icons and progress bars.
- `src/components/sections/Projects.tsx`: Grid of project cards using generated images.
- `src/components/sections/Experience.tsx`: Vertical timeline for education/learning.
- `src/components/sections/Certifications.tsx`: Grid of certificates.
- `src/components/sections/Contact.tsx`: Contact form and social media links.
- `src/components/ui/AnimatedBackground.tsx`: Particle/Grid effect for the futuristic look.
- `src/components/ui/ProjectCard.tsx`: Reusable component for projects.
- `src/components/ui/SkillCard.tsx`: Reusable component for skills.

## 2. Design System
- **Colors**: Deep Navy/Black background, Cyan and Purple glowing accents.
- **Typography**: Sans-serif (Geist or Inter) for a modern look.
- **Animations**: 
  - Framer Motion for scroll-reveal.
  - Hover effects on cards (glowing borders).
  - Animated typing effect in Hero.

## 3. Implementation Steps
1. Define shared UI components (Button, Card, Input).
2. Build the Layout (Navbar, Footer).
3. Implement sections one by one starting from Hero.
4. Integrate Framer Motion for scroll animations.
5. Finalize responsiveness and accessibility.
6. Run `validate_build`.

## 4. Key Content
- **Name**: Kiros Asefa
- **Titles**: AI Engineer | Software Developer | Full Stack Developer
- **University**: Mekelle University (5th Year CSE)
- **Projects**: 
  - AI Fake News Detection (Tigrigna)
  - CNN Crop Disease Detection
  - Smart Rural Tourism
  - Agricultural Sorting Robot
