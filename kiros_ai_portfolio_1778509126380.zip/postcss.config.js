export default {
  plugins: {},
};
