import React from 'react';
import { Cpu, Github, Linkedin, Twitter, Mail } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="py-12 border-t border-white/10 bg-black">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-cyan-400 to-purple-600 rounded flex items-center justify-center">
              <Cpu className="text-white w-5 h-5" />
            </div>
            <span className="text-lg font-bold text-white tracking-tighter">
              KIROS.AI
            </span>
          </div>

          <div className="flex gap-8 text-sm text-gray-500 font-medium">
            <a href="#about" className="hover:text-cyan-400 transition-colors">About</a>
            <a href="#projects" className="hover:text-cyan-400 transition-colors">Projects</a>
            <a href="#experience" className="hover:text-cyan-400 transition-colors">Journey</a>
            <a href="#contact" className="hover:text-cyan-400 transition-colors">Contact</a>
          </div>

          <div className="flex items-center gap-4">
            <a href="#" className="p-2 text-gray-500 hover:text-white transition-colors"><Github size={20} /></a>
            <a href="#" className="p-2 text-gray-500 hover:text-white transition-colors"><Linkedin size={20} /></a>
            <a href="#" className="p-2 text-gray-500 hover:text-white transition-colors"><Twitter size={20} /></a>
            <a href="#" className="p-2 text-gray-500 hover:text-white transition-colors"><Mail size={20} /></a>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-white/5 text-center text-xs text-gray-600">
          <p>© {new Date().getFullYear()} Kiros Asefa. Built with passion for AI and Software Engineering.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;