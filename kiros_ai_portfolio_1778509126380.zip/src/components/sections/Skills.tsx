import React from 'react';
import { motion } from 'framer-motion';

interface Skill {
  name: string;
  level: number;
}

interface SkillCategory {
  title: string;
  skills: Skill[];
}

const Skills: React.FC = () => {
  const categories: SkillCategory[] = [
    {
      title: "Programming",
      skills: [
        { name: "Python", level: 90 },
        { name: "JavaScript", level: 85 },
        { name: "Java", level: 80 },
        { name: "C++", level: 75 },
        { name: "SQL", level: 85 },
      ]
    },
    {
      title: "AI / ML",
      skills: [
        { name: "TensorFlow", level: 80 },
        { name: "Scikit-learn", level: 85 },
        { name: "NLP", level: 75 },
        { name: "CNN", level: 80 },
        { name: "Data Processing", level: 90 },
      ]
    },
    {
      title: "Web Stack",
      skills: [
        { name: "React", level: 90 },
        { name: "FastAPI", level: 85 },
        { name: "Node.js", level: 80 },
        { name: "Tailwind CSS", level: 95 },
        { name: "Express", level: 80 },
      ]
    },
    {
      title: "Tools & Platforms",
      skills: [
        { name: "Git & GitHub", level: 90 },
        { name: "Firebase", level: 80 },
        { name: "Streamlit", level: 85 },
        { name: "Linux", level: 75 },
        { name: "Vercel/Render", level: 80 },
      ]
    }
  ];

  return (
    <section id="skills" className="py-24 bg-white/[0.02]">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-black mb-4"
          >
            Technical <span className="text-cyan-400">Arsenal</span>
          </motion.h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            A comprehensive overview of my technical expertise across artificial intelligence, full-stack development, and modern engineering tools.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {categories.map((cat, idx) => (
            <motion.div
              key={cat.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="p-6 rounded-3xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all group"
            >
              <h3 className="text-xl font-bold text-white mb-6 group-hover:text-cyan-400 transition-colors">
                {cat.title}
              </h3>
              <div className="space-y-6">
                {cat.skills.map((skill) => (
                  <div key={skill.name}>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-300 font-medium">{skill.name}</span>
                      <span className="text-cyan-400">{skill.level}%</span>
                    </div>
                    <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        whileInView={{ width: `${skill.level}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1, delay: 0.5 }}
                        className="h-full bg-gradient-to-r from-cyan-400 to-purple-600 rounded-full"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;