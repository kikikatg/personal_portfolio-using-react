import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, ChevronRight } from 'lucide-react';

const Experience: React.FC = () => {
  const timeline = [
    {
      year: "2020 - Present",
      title: "B.Sc. in Computer Science & Engineering",
      org: "Mekelle University",
      desc: "Focusing on advanced algorithms, software engineering, and AI systems. Maintaining high academic performance while leading student tech initiatives.",
      type: "education"
    },
    {
      year: "2023",
      title: "AI Research & Development",
      org: "Personal Initiative",
      desc: "Developed a Tigrigna Fake News Detection system using NLP, handling local language nuances and dialect variations.",
      type: "project"
    },
    {
      year: "2022",
      title: "Full Stack Development Intensive",
      org: "Self-Led Mastery",
      desc: "Deep dive into modern web ecosystems: React, Node.js, and Cloud infrastructures (AWS/Firebase).",
      type: "learning"
    },
    {
      year: "2021",
      title: "Introduction to Machine Learning",
      org: "Online Certification & Practice",
      desc: "Started the journey into neural networks, data preprocessing, and model evaluation techniques.",
      type: "learning"
    }
  ];

  return (
    <section id="experience" className="py-24 bg-black">
      <div className="container mx-auto px-6">
        <div className="text-center mb-20">
          <h2 className="text-4xl md:text-5xl font-black mb-4">The <span className="text-cyan-400">Journey</span></h2>
          <p className="text-gray-400">A timeline of my growth as an engineer and problem solver.</p>
        </div>

        <div className="max-w-4xl mx-auto relative">
          {/* Vertical Line */}
          <div className="absolute left-0 md:left-1/2 md:-translate-x-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-cyan-500/50 via-purple-500/50 to-transparent" />

          <div className="space-y-12">
            {timeline.map((item, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: idx % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className={`relative flex items-center gap-8 ${idx % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}
              >
                {/* Dot */}
                <div className="absolute left-0 md:left-1/2 md:-translate-x-1/2 w-4 h-4 bg-cyan-500 rounded-full border-4 border-black z-10 shadow-[0_0_10px_rgba(6,182,212,0.8)]" />

                <div className="flex-1 ml-10 md:ml-0 md:w-1/2">
                  <div className={`p-8 rounded-[2rem] bg-white/[0.02] border border-white/10 hover:border-white/20 transition-all ${idx % 2 === 0 ? 'md:text-right' : 'md:text-left'}`}>
                    <div className={`flex items-center gap-2 mb-3 text-cyan-400 font-mono text-sm ${idx % 2 === 0 ? 'md:justify-end' : 'md:justify-start'}`}>
                      <Calendar size={14} /> {item.year}
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
                    <p className="text-purple-400 font-semibold mb-4 text-sm tracking-wide uppercase">{item.org}</p>
                    <p className="text-gray-400 text-sm leading-relaxed">{item.desc}</p>
                  </div>
                </div>
                <div className="hidden md:block md:flex-1" />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Experience;