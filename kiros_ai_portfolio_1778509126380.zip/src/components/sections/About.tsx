import React from 'react';
import { motion } from 'framer-motion';
import { GraduationCap, Brain, Code, Zap } from 'lucide-react';

const About: React.FC = () => {
  const highlights = [
    { icon: <GraduationCap />, label: "5th Year CSE", detail: "Mekelle University" },
    { icon: <Brain />, label: "AI Focused", detail: "NLP & ML Specialist" },
    { icon: <Code />, label: "Full Stack", detail: "React, Node, Python" },
    { icon: <Zap />, label: "Problem Solver", detail: "Fast & Efficient" },
  ];

  return (
    <section id="about" className="py-24 relative">
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:w-1/2"
          >
            <h2 className="text-4xl md:text-5xl font-black mb-8">
              Deciphering the <span className="text-cyan-400">Future</span> 
              <br />Through Code.
            </h2>
            <p className="text-gray-400 text-lg leading-relaxed mb-6">
              I am a final-year Computer Science and Engineering student at Mekelle University with a deep-seated passion for Artificial Intelligence and Software Engineering. My journey is fueled by a desire to solve complex real-world problems using intelligent systems.
            </p>
            <p className="text-gray-400 text-lg leading-relaxed mb-8">
              From developing NLP systems for local languages to building vision-based agricultural robots, I strive to create software that doesn't just work, but thinks and evolves.
            </p>

            <div className="grid grid-cols-2 gap-6">
              {highlights.map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="p-4 rounded-2xl bg-white/5 border border-white/10 hover:border-cyan-500/50 transition-colors"
                >
                  <div className="text-cyan-400 mb-2">{item.icon}</div>
                  <div className="text-white font-bold">{item.label}</div>
                  <div className="text-gray-500 text-sm">{item.detail}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="lg:w-1/2 relative"
          >
            <div className="relative z-10 rounded-3xl overflow-hidden border-2 border-white/10 group">
              <img 
                src="https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&q=80&w=800" 
                alt="AI Tech" 
                className="w-full h-[500px] object-cover group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-60" />
              <div className="absolute bottom-6 left-6 right-6 p-6 bg-black/40 backdrop-blur-md rounded-2xl border border-white/10">
                <p className="text-sm italic text-gray-300">
                  "The best way to predict the future is to invent it."
                </p>
                <p className="text-xs font-bold text-cyan-400 mt-2">— Kiros Asefa</p>
              </div>
            </div>
            {/* Decoration */}
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-purple-600/20 blur-3xl rounded-full" />
            <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-cyan-600/20 blur-3xl rounded-full" />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;