import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Download, Mail } from 'lucide-react';

const Hero: React.FC = () => {
  const [text, setText] = useState('');
  const titles = ["AI Engineer", "Software Developer", "Full Stack Developer"];
  const [index, setIndex] = useState(0);
  const [charIndex, setCharIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const typeSpeed = isDeleting ? 50 : 150;
    const currentTitle = titles[index];

    const timeout = setTimeout(() => {
      if (!isDeleting && charIndex < currentTitle.length) {
        setText(currentTitle.substring(0, charIndex + 1));
        setCharIndex(prev => prev + 1);
      } else if (isDeleting && charIndex > 0) {
        setText(currentTitle.substring(0, charIndex - 1));
        setCharIndex(prev => prev - 1);
      } else if (!isDeleting && charIndex === currentTitle.length) {
        setTimeout(() => setIsDeleting(true), 1500);
      } else {
        setIsDeleting(false);
        setIndex((prev) => (prev + 1) % titles.length);
        setCharIndex(0);
      }
    }, typeSpeed);

    return () => clearTimeout(timeout);
  }, [charIndex, isDeleting, index]);

  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      <div className="container mx-auto px-6 z-10">
        <div className="max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-block px-4 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-sm font-medium mb-6"
          >
            Available for Opportunities
          </motion.div>
          
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-6xl md:text-8xl font-black mb-6 tracking-tight leading-none"
          >
            I'm <span className="bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-purple-600">Kiros Asefa</span>
          </motion.h1>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="text-2xl md:text-4xl font-mono text-gray-400 mb-8 flex items-center h-12"
          >
            <span>{text}</span>
            <span className="w-1 h-8 bg-cyan-400 ml-2 animate-pulse" />
          </motion.div>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="text-gray-400 text-lg md:text-xl max-w-2xl mb-10 leading-relaxed"
          >
            A Computer Science & Engineering student specializing in building 
            <span className="text-white"> intelligent systems</span> and 
            <span className="text-white"> full-stack applications</span>. 
            Passionate about bridging the gap between human intuition and machine intelligence.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.8 }}
            className="flex flex-wrap gap-4"
          >
            <a 
              href="#projects"
              className="flex items-center gap-2 px-8 py-4 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl font-bold transition-all transform hover:scale-105 shadow-[0_0_20px_rgba(8,145,178,0.4)]"
            >
              View Projects <ArrowRight size={20} />
            </a>
            <button className="flex items-center gap-2 px-8 py-4 bg-white/5 hover:bg-white/10 text-white border border-white/10 rounded-xl font-bold transition-all">
              Download CV <Download size={20} />
            </button>
            <a 
              href="#contact"
              className="flex md:hidden items-center gap-2 px-8 py-4 bg-transparent text-white border border-cyan-500/50 rounded-xl font-bold"
            >
              Contact <Mail size={20} />
            </a>
          </motion.div>
        </div>
      </div>

      {/* Hero Animation Element */}
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 0.1, scale: 1 }}
        transition={{ duration: 2, repeat: Infinity, repeatType: "reverse" }}
        className="absolute right-[-10%] top-1/4 hidden lg:block"
      >
        <div className="w-[600px] h-[600px] rounded-full border-[1px] border-cyan-500/20 animate-spin-slow" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] rounded-full border-[1px] border-purple-500/20 animate-reverse-spin" />
      </motion.div>
    </section>
  );
};

export default Hero;