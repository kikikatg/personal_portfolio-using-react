import React from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, Github } from 'lucide-react';

const Projects: React.FC = () => {
  const projects = [
    {
      title: "AI Fake News Detection",
      desc: "NLP-based Tigrigna fake news detection using machine learning. Features real-time analysis and confidence scoring.",
      image: "https://storage.googleapis.com/dala-prod-public-storage/generated-images/01a16e85-de99-4f80-810f-4ea5eb234a67/fake-news-detection-system-d62f85cc-1778508825713.webp",
      tags: ["NLP", "FastAPI", "React", "Python"],
      github: "#",
      demo: "#"
    },
    {
      title: "CNN Crop Disease Detection",
      desc: "An image classification system built with TensorFlow to help farmers diagnose plant diseases quickly via mobile.",
      image: "https://storage.googleapis.com/dala-prod-public-storage/generated-images/01a16e85-de99-4f80-810f-4ea5eb234a67/crop-disease-detection-260ea8fd-1778508825251.webp",
      tags: ["TensorFlow", "Streamlit", "CNN", "Vision"],
      github: "#",
      demo: "#"
    },
    {
      title: "Smart Rural Tourism Platform",
      desc: "A web-based ecosystem designed to promote and manage rural tourism sites in Ethiopia.",
      image: "https://storage.googleapis.com/dala-prod-public-storage/generated-images/01a16e85-de99-4f80-810f-4ea5eb234a67/tourism-promotion-system-8f31ea0d-1778508825774.webp",
      tags: ["Full Stack", "React", "Mapbox", "Node"],
      github: "#",
      demo: "#"
    },
    {
      title: "Agricultural Sorting Robot",
      desc: "An AI-powered robot that uses real-time object detection to separate crops from weeds in greenhouses.",
      image: "https://storage.googleapis.com/dala-prod-public-storage/generated-images/01a16e85-de99-4f80-810f-4ea5eb234a67/agricultural-sorting-robot-4038f1bf-1778508826441.webp",
      tags: ["Robotics", "Computer Vision", "YOLO", "AI"],
      github: "#",
      demo: "#"
    }
  ];

  return (
    <section id="projects" className="py-24 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div className="max-w-2xl">
            <motion.h2 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="text-4xl md:text-5xl font-black mb-4"
            >
              Featured <span className="text-purple-500">Projects</span>
            </motion.h2>
            <p className="text-gray-400">
              A selection of my work ranging from pure AI research to functional full-stack applications solving real-world challenges.
            </p>
          </div>
          <button className="px-6 py-3 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-all">
            See All Projects
          </button>
        </div>

        <div className="grid md:grid-cols-2 gap-10">
          {projects.map((project, idx) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="group relative bg-white/[0.03] border border-white/10 rounded-[2.5rem] overflow-hidden hover:border-cyan-500/40 transition-all"
            >
              <div className="aspect-video overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
              </div>
              <div className="p-8">
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tags.map(tag => (
                    <span key={tag} className="px-3 py-1 bg-white/5 border border-white/10 rounded-full text-xs text-gray-400">
                      {tag}
                    </span>
                  ))}
                </div>
                <h3 className="text-2xl font-bold mb-3 group-hover:text-cyan-400 transition-colors">
                  {project.title}
                </h3>
                <p className="text-gray-400 mb-6 line-clamp-2">
                  {project.desc}
                </p>
                <div className="flex gap-4">
                  <a href={project.github} className="flex items-center gap-2 text-sm font-bold text-white hover:text-cyan-400 transition-colors">
                    <Github size={18} /> Code
                  </a>
                  <a href={project.demo} className="flex items-center gap-2 text-sm font-bold text-white hover:text-cyan-400 transition-colors">
                    <ExternalLink size={18} /> Demo
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;