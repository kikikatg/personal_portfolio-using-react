import React from 'react';
import { motion } from 'framer-motion';
import { Award, ShieldCheck, CheckCircle } from 'lucide-react';

const Certifications: React.FC = () => {
  const certs = [
    {
      title: "Machine Learning Specialization",
      issuer: "DeepLearning.AI / Coursera",
      date: "2023",
      icon: <Award className="text-yellow-500" />
    },
    {
      title: "Full Stack Web Development",
      issuer: "Meta / Coursera",
      date: "2022",
      icon: <ShieldCheck className="text-blue-500" />
    },
    {
      title: "Natural Language Processing",
      issuer: "Stanford Online",
      date: "2023",
      icon: <CheckCircle className="text-green-500" />
    },
    {
      title: "Cisco Networking Basics",
      issuer: "Cisco Academy",
      date: "2021",
      icon: <Award className="text-cyan-500" />
    }
  ];

  return (
    <section id="certs" className="py-24 bg-white/[0.01]">
      <div className="container mx-auto px-6">
        <div className="mb-16">
          <h2 className="text-4xl font-black mb-4 text-center md:text-left">
            Credentials & <span className="text-cyan-400">Honors</span>
          </h2>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {certs.map((cert, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              whileHover={{ y: -5 }}
              className="p-6 rounded-2xl bg-white/5 border border-white/10 flex items-start gap-4"
            >
              <div className="mt-1">{cert.icon}</div>
              <div>
                <h3 className="text-white font-bold leading-tight mb-1">{cert.title}</h3>
                <p className="text-gray-500 text-xs mb-2">{cert.issuer}</p>
                <span className="text-[10px] px-2 py-0.5 bg-white/5 rounded-full text-gray-400 uppercase tracking-widest font-bold">
                  {cert.date}
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Certifications;